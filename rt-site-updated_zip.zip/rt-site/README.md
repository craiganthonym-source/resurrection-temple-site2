# Resurrection Temple — resurrectiontemple.com
## Full Website + Client Portal — Custom Host Deployment

### Stack
- **Frontend:** Vanilla HTML/CSS/JS (zero dependencies, fast, deployable anywhere)
- **Backend:** Node.js + Express (API server)
- **Email:** Nodemailer (SMTP — plug in any provider)
- **PDF/Contract generation:** Server-side HTML→PDF via Puppeteer
- **Database:** JSON flat-file (swap for MySQL/PostgreSQL easily)

### Project Structure
```
rt-site/
├── public/               ← Static site (www.resurrectiontemple.com)
│   ├── index.html        ← Main ecosystem homepage
│   ├── css/
│   │   └── main.css      ← Global styles
│   ├── js/
│   │   └── main.js       ← Navigation + interactions
│   └── pages/            ← Division pages
│       ├── builders.html
│       ├── transport.html
│       └── ... (all 13 divisions)
├── portal/               ← Client portal (/portal)
│   ├── index.html        ← Portal dashboard
│   ├── intake.html       ← Intake + service selection form
│   ├── contracts.html    ← Contract viewer + sign
│   ├── invoice.html      ← Invoice viewer
│   └── css/js/           ← Portal-specific assets
├── api/
│   └── server.js         ← Express API (forms, contracts, email)
├── contracts/
│   └── templates.js      ← All 8 contract templates (JS)
├── package.json
└── .env.example          ← Environment variables template
```

### Quick Deploy (VPS / Custom Host)
```bash
# 1. Upload this folder to your server
# 2. Install dependencies
npm install

# 3. Copy and fill in environment variables
cp .env.example .env
nano .env

# 4. Start the server
node api/server.js
# OR with PM2 (recommended for production):
npm install -g pm2
pm2 start api/server.js --name rt-site
pm2 save

# 5. Point your web server (nginx/Apache) to port 3000
# See nginx config below
```

### Nginx Config (resurrectiontemple.com)
```nginx
server {
    listen 80;
    server_name resurrectiontemple.com www.resurrectiontemple.com;
    return 301 https://$host$request_uri;
}
server {
    listen 443 ssl;
    server_name resurrectiontemple.com www.resurrectiontemple.com;
    ssl_certificate /etc/letsencrypt/live/resurrectiontemple.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/resurrectiontemple.com/privkey.pem;
    root /var/www/rt-site/public;
    index index.html;
    location /portal { try_files $uri $uri/ /portal/index.html; }
    location /api { proxy_pass http://localhost:3000; proxy_set_header Host $host; }
    location / { try_files $uri $uri.html $uri/ =404; }
}
```

### Environment Variables (.env)
```
PORT=3000
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=cmayweather@ResurrectionTemple.org
EMAIL_PASS=your_app_password
NOTIFY_EMAIL=cmayweather@ResurrectionTemple.org
SESSION_SECRET=change_this_to_random_string
```
