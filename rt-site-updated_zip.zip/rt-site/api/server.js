/* ══════════════════════════════════════════════════════════════
   RESURRECTION TEMPLE — API SERVER
   Node.js + Express
   ══════════════════════════════════════════════════════════════ */

'use strict';

require('dotenv').config();
const express    = require('express');
const nodemailer = require('nodemailer');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const { v4: uuidv4 } = require('uuid');
const fs         = require('fs');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── MIDDLEWARE ──────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: ['https://www.resurrectiontemple.com', 'https://resurrectiontemple.com', 'http://localhost:3000'] }));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiter for form submissions
const formLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: { ok: false, error: 'Too many submissions. Please try again in 15 minutes.' }
});

// ── STATIC FILES ────────────────────────────────────────────────────
const PUBLIC = path.join(__dirname, '..', 'public');
const PORTAL = path.join(__dirname, '..', 'portal');

app.use(express.static(PUBLIC));
app.use('/portal', express.static(PORTAL));

// ── EMAIL TRANSPORTER ───────────────────────────────────────────────
const transporter = nodemailer.createTransport({
  host:   process.env.EMAIL_HOST || 'smtp.gmail.com',
  port:   parseInt(process.env.EMAIL_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// ── EMAIL HELPER ────────────────────────────────────────────────────
async function sendNotification(subject, htmlBody) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.log('[EMAIL SKIPPED — no credentials configured]\n', subject);
    return;
  }
  await transporter.sendMail({
    from:    `"Resurrection Temple Website" <${process.env.EMAIL_USER}>`,
    to:      process.env.NOTIFY_EMAIL || 'cmayweather@ResurrectionTemple.org',
    subject: `[RT Website] ${subject}`,
    html:    htmlBody
  });
}

async function sendAutoReply(toEmail, toName, formType) {
  if (!process.env.EMAIL_USER || !toEmail) return;
  const messages = {
    'client-intake':    'Your client intake form has been received. A member of our team will review your submission and contact you within 24 business hours.',
    'general-contact':  'Your message has been received. We will respond within 24–48 business hours.',
    'invoice-request':  'Your invoice request has been received. We will confirm your total and send payment instructions within 24 hours.',
    'default':          'Your submission has been received. We will be in touch shortly.'
  };
  await transporter.sendMail({
    from:    `"Resurrection Temple Ministries" <${process.env.EMAIL_USER}>`,
    to:      toEmail,
    subject: 'Resurrection Temple Ministries — Submission Received',
    html: `
      <div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:2rem;color:#1A1A1A;">
        <div style="border-bottom:2px solid #C9A84C;padding-bottom:1rem;margin-bottom:1.5rem;">
          <h2 style="font-weight:400;color:#1A1A1A;margin:0;">Resurrection Temple Ministries</h2>
          <p style="font-size:12px;color:#888;margin:4px 0 0;">resurrectiontemple.com · (626) 479-1082</p>
        </div>
        <p>Dear ${toName || 'Client'},</p>
        <p>${messages[formType] || messages['default']}</p>
        <p>If you have any immediate questions, please call us at <strong>(626) 479-1082</strong> or reply to this email.</p>
        <p style="margin-top:2rem;">With purpose,<br><strong>Craig A. Mayweather</strong><br>President, Resurrection Temple Ministries</p>
        <div style="margin-top:2rem;padding-top:1rem;border-top:1px solid #eee;font-size:11px;color:#999;">
          301 E Arrow Hwy Ste 101-#815 · San Dimas, CA 91773<br>
          cmayweather@ResurrectionTemple.org · resurrectiontemple.com
        </div>
      </div>
    `
  });
}

// ── DATA STORE (flat JSON — swap for DB in production) ──────────────
const DATA_FILE = path.join(__dirname, 'submissions.json');
function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; }
}
function saveData(submissions) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(submissions, null, 2));
}

// ── CONTACT / FORM API ──────────────────────────────────────────────
app.post('/api/contact', formLimiter, async (req, res) => {
  try {
    const { formType = 'general-contact', name, email, ...rest } = req.body;

    // Basic validation
    if (!name || name.trim().length < 2) return res.status(400).json({ ok: false, error: 'Name is required.' });

    const id = uuidv4();
    const timestamp = new Date().toISOString();
    const record = { id, timestamp, formType, name, email, ...rest };

    // Save to JSON store
    const submissions = loadData();
    submissions.push(record);
    saveData(submissions);

    // Build notification email
    const fieldRows = Object.entries({ name, email, ...rest })
      .filter(([k]) => !['formType'].includes(k))
      .map(([k, v]) => `<tr><td style="padding:6px 10px;color:#666;font-size:12px;border-bottom:1px solid #f0f0f0;">${k}</td><td style="padding:6px 10px;font-size:12px;border-bottom:1px solid #f0f0f0;">${v || '—'}</td></tr>`)
      .join('');

    await sendNotification(
      `New ${formType} from ${name}`,
      `<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;">
        <h2 style="background:#1A1A1A;color:#C9A84C;padding:1rem 1.5rem;margin:0;">New Submission: ${formType}</h2>
        <table style="width:100%;border-collapse:collapse;margin:1rem 0;">
          <tr><td style="padding:6px 10px;color:#666;font-size:12px;border-bottom:1px solid #f0f0f0;">Submission ID</td><td style="padding:6px 10px;font-size:12px;border-bottom:1px solid #f0f0f0;">${id}</td></tr>
          <tr><td style="padding:6px 10px;color:#666;font-size:12px;border-bottom:1px solid #f0f0f0;">Timestamp</td><td style="padding:6px 10px;font-size:12px;border-bottom:1px solid #f0f0f0;">${timestamp}</td></tr>
          ${fieldRows}
        </table>
      </div>`
    );

    // Auto-reply to client
    if (email) await sendAutoReply(email, name, formType);

    res.json({ ok: true, id });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ ok: false, error: 'Server error. Please try again.' });
  }
});

// ── SUBMISSIONS VIEWER (basic admin — add auth before going live) ────
app.get('/api/submissions', (req, res) => {
  // TODO: Add authentication middleware here before deploying
  const submissions = loadData();
  res.json({ count: submissions.length, submissions });
});

// ── HEALTH CHECK ────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, timestamp: new Date().toISOString(), version: '1.0.0' });
});

// ── SPA FALLBACK ROUTES ─────────────────────────────────────────────
app.get('/portal', (req, res) => res.sendFile(path.join(PORTAL, 'index.html')));
app.get('/portal/intake', (req, res) => res.sendFile(path.join(PORTAL, 'intake.html')));
app.get('/portal/contracts', (req, res) => res.sendFile(path.join(PORTAL, 'contracts.html')));
app.get('/portal/invoice', (req, res) => res.sendFile(path.join(PORTAL, 'invoice.html')));
app.get('/portal/pricing', (req, res) => res.sendFile(path.join(PORTAL, 'pricing.html')));
app.get('/pages/:page', (req, res) => {
  const file = path.join(PUBLIC, 'pages', `${req.params.page}.html`);
  if (fs.existsSync(file)) res.sendFile(file);
  else res.status(404).sendFile(path.join(PUBLIC, '404.html'));
});
app.get('*', (req, res) => res.sendFile(path.join(PUBLIC, 'index.html')));

// ── START ────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🏛  Resurrection Temple — resurrectiontemple.com`);
  console.log(`✅  Server running on port ${PORT}`);
  console.log(`📧  Email: ${process.env.EMAIL_USER || '(not configured — set .env)'}`);
  console.log(`\n   http://localhost:${PORT}`);
  console.log(`   http://localhost:${PORT}/portal\n`);
});

module.exports = app;
